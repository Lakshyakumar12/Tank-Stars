<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="trees" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="648" columns="18">
 <image source="tree.png" width="332" height="656"/>
</tileset>
