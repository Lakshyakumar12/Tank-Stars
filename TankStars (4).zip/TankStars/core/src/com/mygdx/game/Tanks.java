package com.mygdx.game;

public interface Tanks {
    public void update(float dt);
    public void handleInput();
    public void defineTank();
}
