<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="chooseTank2" tilewidth="32" tileheight="32" tilecount="4" columns="4">
 <image source="../chooseTank2.png" width="130" height="56"/>
</tileset>
